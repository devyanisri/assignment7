import java.util.Scanner;
public class Ques4{
    public static void main(String[]args){
        int a[]= new int[4];
        int rev[]= new int[4];
        int k=0;
        Scanner s=  new Scanner(System.in);
        for(int i=0;i<4;i++){
            a[i]=s.nextInt();
        }
        for (int i=3;i>=0;i--) {
        	rev[k]=a[i];
        	k++;
        }
        
for( int z=0;z<4;z++){
    //System.out.println("original array is:");
    System.out.print(a[z]+" ");
    }
System.out.println();
    //System.out.println("rev array is:");
    for( int z=0;z<4;z++){
    System.out.print(rev[z]+" ");
}
    }}