public class Assign{
    public static void main(String[]args){
 String [] s1={"hfy","jgui","uituigui"};
 String [] s2={"ghj","jgui","olk","pol"};
 String [] s3= new String[s2.length];
int k=0;
int flag=0;
 for(int i=0;i<s2.length;i++){
for(int j=0;j<s1.length;j++){
    if(s2[i]==s1[j]){

        flag=0;
        break;
    }
    else{
        flag=1;
    }
}
if (flag==1){
    s3[k++]=s2[i];
}
 }
 for (int i=0;i<s3.length;i++){
     System.out.println(s3[i]);
 }
}}